<?= $this->extend('layout/templates'); ?>

<?= $this->section('content'); ?>

<div class="container">
    <div class="row">
        <div class="col">

            <h1>About Me</h1>
            <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Cum, ad accusantium possimus officia, et, vero ab autem beatae fuga maxime illo laboriosam eligendi! Sed, eos voluptatibus? Harum error esse sit!</p>

        </div>
    </div>
</div>

<?= $this->endSection(); ?>